import React from "react";

interface Props {
  timings: {
    wait: number;
    scan: number;
  };
  onScan: () => void;
  scanning: boolean;
  done: boolean;
}

const ScanButton: React.FC<Props> = ({ onScan, scanning, done }) => {
  return (
    <button className="scan-btn" onClick={onScan} disabled={scanning || done}>
      <span className="dot" />
    </button>
  );
};

export default ScanButton;
