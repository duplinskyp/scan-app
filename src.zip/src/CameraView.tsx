import React, { useEffect, useRef, useState } from "react";

interface Props {
  scanning: boolean;
  done: boolean;
}

interface Dot {
  top: string;
  left: string;
  size: string;
}

const CameraView: React.FC<Props> = ({ scanning, done }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [dots, setDots] = useState<Dot[]>([]);

  useEffect(() => {
    navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } })
      .then((stream) => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      })
      .catch(console.error);
  }, []);

  useEffect(() => {
    if (scanning) {
      const newDots = Array.from({ length: 20 }, () => ({
        top: `${Math.random() * 60 + 20}%`,
        left: `${Math.random() * 80 + 10}%`,
        size: `${Math.random() * 6 + 6}px`
      }));
      setDots(newDots);
    } else {
      setDots([]);
    }
  }, [scanning]);

  return (
    <div className="camera-container">
      <video ref={videoRef} autoPlay playsInline muted className="camera-view" />
      <div className="scan-frame" />
      {scanning && (
        <>
          <div className="scan-line" />
          <div className="feature-dots">
            {dots.map((dot, index) => (
              <div
                key={index}
                className="feature-dot"
                style={{
                  top: dot.top,
                  left: dot.left,
                  width: dot.size,
                  height: dot.size
                }}
              />
            ))}
          </div>
        </>
      )}
      {done && <div className="checkmark check-animated">✓</div>}
    </div>
  );
};

export default CameraView;
