import React, { useState } from "react";
import CameraView from "./CameraView";
import ScanButton from "./ScanButton";
import CodeViewer from "./CodeViewer";
import Settings from "./Settings";
import "./styles.css";
import { Eye, Settings as Cog } from "lucide-react";

const App: React.FC = () => {
  const [showSettings, setShowSettings] = useState(false);
  const [codes, setCodes] = useState<string[]>(["ABC123", "DEF456", "GHI789"]);
  const [timings, setTimings] = useState({ wait: 2000, scan: 2000 });
  const [showCode, setShowCode] = useState(false);
  const [currentCode, setCurrentCode] = useState(0);
  const [scanning, setScanning] = useState(false);
  const [done, setDone] = useState(false);

  const handleScan = () => {
    setScanning(true);
    setTimeout(() => {
      setScanning(false);
      setDone(true);
      setTimeout(() => setDone(false), 2000);
    }, timings.wait + timings.scan);
  };

  const handleCodeClick = () => setShowCode(true);
  const handleCameraClick = () => {
    if (showCode) {
      setShowCode(false);
      setCurrentCode((prev) => (prev + 1) % codes.length);
    }
  };

  return (
    <div className="app">
      {showSettings ? (
        <Settings
          codes={codes}
          setCodes={setCodes}
          timings={timings}
          setTimings={setTimings}
          onClose={() => setShowSettings(false)}
        />
      ) : (
        <div className="camera-wrapper" onClick={handleCameraClick}>
          <CameraView scanning={scanning} done={done} />
          <div className="overlay-ui">
            <ScanButton timings={timings} onScan={handleScan} scanning={scanning} done={done} />
            <button className="code-btn" onClick={handleCodeClick} aria-label="Zobraziť kód">
              <Eye size={20} />
            </button>
            <button className="settings-btn" onClick={() => setShowSettings(true)} aria-label="Nastavenia">
              <Cog size={20} />
            </button>
          </div>
          {showCode && <CodeViewer code={codes[currentCode]} />}
        </div>
      )}
    </div>
  );
};

export default App;
