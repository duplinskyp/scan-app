import React from "react";

interface Props {
  codes: string[];
  setCodes: (codes: string[]) => void;
  timings: {
    wait: number;
    scan: number;
  };
  setTimings: (timings: { wait: number; scan: number }) => void;
  onClose: () => void;
}

const Settings: React.FC<Props> = ({ codes, setCodes, timings, setTimings, onClose }) => {
  const handleCodeChange = (index: number, value: string) => {
    const updated = [...codes];
    updated[index] = value;
    setCodes(updated);
  };

  const addCode = () => setCodes([...codes, ""]);
  const removeCode = (index: number) => {
    const updated = codes.filter((_, i) => i !== index);
    setCodes(updated);
  };

  return (
    <div className="settings">
      <h2>Nastavenia</h2>

      <label>
        Čas čakania (ms):
        <input
          type="number"
          value={timings.wait}
          onChange={(e) => setTimings({ ...timings, wait: +e.target.value })}
        />
      </label>

      <label>
        Čas skenovania (ms):
        <input
          type="number"
          value={timings.scan}
          onChange={(e) => setTimings({ ...timings, scan: +e.target.value })}
        />
      </label>

      <h3>Kódy</h3>
      {codes.map((code, index) => (
        <div key={index} className="code-item">
          <input
            type="text"
            value={code}
            onChange={(e) => handleCodeChange(index, e.target.value)}
          />
          <button onClick={() => removeCode(index)}>🗑️</button>
        </div>
      ))}

      <button onClick={addCode}>➕ Pridať kód</button>
      <button onClick={onClose}>Zavrieť</button>
    </div>
  );
};

export default Settings;
