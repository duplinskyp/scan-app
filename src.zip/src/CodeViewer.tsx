import React from "react";

interface Props {
  code: string;
}

const CodeViewer: React.FC<Props> = ({ code }) => {
  return <div className="code-viewer">{code}</div>;
};

export default CodeViewer;